#ifndef __AK_DBG_H__
#define __AK_DBG_H__

#ifdef __cplusplus
extern "C"
{
#endif

#ifdef __cplusplus
}
#endif

#endif //__AK_DBG_H__
