#ifndef __TASK_UART_IF_H__
#define __TASK_UART_IF_H__

#include <stdint.h>

extern uint8_t rx_frame_parser(uint8_t);

#endif //__TASK_UART_IF_H__
