#ifndef TASK_DISPLAY_H
#define TASK_DISPLAY_H


class task_display
{
public:
	task_display();
};

#endif // TASK_DISPLAY_H