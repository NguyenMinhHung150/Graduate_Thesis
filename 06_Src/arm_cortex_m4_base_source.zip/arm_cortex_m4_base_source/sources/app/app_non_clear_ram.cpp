#include "app_non_clear_ram.h"

uint32_t sys_soft_reboot_counter __attribute__ ((section ("non_clear_ram")));
