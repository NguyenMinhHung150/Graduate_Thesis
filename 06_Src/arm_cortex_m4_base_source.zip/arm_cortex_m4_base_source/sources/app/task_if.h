#ifndef __TASK_IF_H__
#define __TASK_IF_H__

#include <stdint.h>
#include <stdbool.h>

#include "../ak/ak.h"
#include "../ak/message.h"

#endif // __TASK_IF_H__
